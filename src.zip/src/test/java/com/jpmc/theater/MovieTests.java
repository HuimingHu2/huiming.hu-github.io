package com.jpmc.theater;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MovieTests {
    @Test
    void specialMovieWith20PercentDiscount() {
        Movie spiderMan = new Movie("Spider-Man: No Way Home", Duration.ofMinutes(90),12.5, 1);
        Showing showing = new Showing(spiderMan, 5, LocalDateTime.of(LocalDate.now(), LocalTime.now()));
        assertEquals(10, spiderMan.calculateTicketPrice(showing));

        System.out.println(Duration.ofMinutes(90));
    }    
       
    @Test
    void firstDayMonthMovieWith3DolalrtDiscount() {
        Movie giantsBill = new Movie("Giants Coach: Bill Parcel", Duration.ofMinutes(135),12, 0);
        Showing showing = new Showing(giantsBill, 1, LocalDateTime.of(LocalDate.now(), LocalTime.now()));
        assertEquals(9, giantsBill.calculateTicketPrice(showing));

        System.out.println(Duration.ofMinutes(135));
    }
    
    @Test
    void seventhDayMonthMovieWith1DolalrtDiscount() {
        Movie loveStory1966 = new Movie("Lover Story: true story", Duration.ofMinutes(100),8, 0);
        Showing showing = new Showing(loveStory1966, 7, LocalDateTime.of(LocalDate.now(), LocalTime.now()));
        assertEquals(7, loveStory1966.calculateTicketPrice(showing));

        System.out.println(Duration.ofMinutes(80));
    }
    
    @Test
    void specialHourMovieWith25PercentDiscount() {
        Movie lunchRoman = new Movie("Lunch roman thing: daily unexcepted story", Duration.ofMinutes(110),8, 0);
        Showing showing = new Showing(lunchRoman, 11, LocalDateTime.of(LocalDate.now(), LocalTime.NOON));
        assertEquals(6, lunchRoman.calculateTicketPrice(showing));

        System.out.println(Duration.ofMinutes(110));
    }
    
    @Test
    void firstDayspecialHourMovieWithDiscount() {
        Movie lunchRoman = new Movie("Fist day of month for Lunch party: daily unexcepted story", Duration.ofMinutes(140),8, 0);
        Showing showing = new Showing(lunchRoman, 1, LocalDateTime.of(LocalDate.now(), LocalTime.NOON));
        assertEquals(5, lunchRoman.calculateTicketPrice(showing));

        System.out.println(Duration.ofMinutes(140));
    }

}
